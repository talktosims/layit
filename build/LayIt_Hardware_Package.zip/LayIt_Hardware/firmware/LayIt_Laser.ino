/**
 * ============================================================================
 * LayIt Laser — Firmware v1.0
 * ============================================================================
 *
 * Tile Pattern Laser Projection System
 * Hardware: ESP32-S3-WROOM-1 (N16R8) + MCP4822 DAC + Galvo Scanner + 520nm Laser
 *
 * This firmware:
 *   1. Creates a WiFi Access Point (or connects to existing network)
 *   2. Runs a WebSocket server to receive pattern data from the LayIt app
 *   3. Parses tile vertex data from .layit JSON format
 *   4. Converts tile outlines into optimized galvo scan paths (point lists)
 *   5. Drives the MCP4822 DAC via SPI to control galvo XY mirrors
 *   6. Controls laser blanking (on/off) via GPIO for TTL
 *   7. Monitors safety interlock switch
 *   8. Provides status via WS2812B RGB LED
 *
 * License: MIT
 * Author: LayIt / Generated with Claude
 * Date: February 2026
 *
 * ============================================================================
 */

#include <WiFi.h>
#include <WebServer.h>
#include <WebSocketsServer.h>
#include <SPI.h>
#include <ArduinoJson.h>
#include <Adafruit_NeoPixel.h>
#include <esp_camera.h>

// ============================================================================
// PIN DEFINITIONS (Match schematic Rev 1.0)
// ============================================================================

// SPI to MCP4822 DAC
#define PIN_SPI_CS    10    // GPIO10 → MCP4822 /CS
#define PIN_SPI_MOSI  11    // GPIO11 → MCP4822 SDI
#define PIN_SPI_CLK   12    // GPIO12 → MCP4822 SCK
#define PIN_DAC_LDAC  13    // GPIO13 → MCP4822 /LDAC (simultaneous latch)

// Laser TTL Control
#define PIN_LASER_TTL 14    // GPIO14 → MOSFET gate (inverted: HIGH=laser OFF)

// Camera DVP Pins
#define PIN_CAM_VSYNC  4
#define PIN_CAM_HREF   5
#define PIN_CAM_PCLK   6
#define PIN_CAM_XCLK   7
#define PIN_CAM_D2    15
#define PIN_CAM_D3    16
#define PIN_CAM_D4    17
#define PIN_CAM_D5    18
#define PIN_CAM_D6     8
#define PIN_CAM_D7     9
#define PIN_CAM_D8    45
#define PIN_CAM_D9    46
#define PIN_CAM_SDA    1
#define PIN_CAM_SCL    2

// Status LED
#define PIN_STATUS_LED 48   // GPIO48 → WS2812B DIN

// Safety Interlock
#define PIN_SAFETY     47   // GPIO47 → Lid switch (LOW = safe, HIGH = kill)

// ============================================================================
// CONFIGURATION
// ============================================================================

// WiFi - Access Point mode (device creates its own network)
#define WIFI_AP_SSID     "LayIt-Laser"
#define WIFI_AP_PASSWORD "layitlaser"  // Min 8 chars for WPA2
#define WIFI_AP_CHANNEL  1
#define WIFI_AP_MAX_CONN 2

// WiFi - Station mode (connect to existing network) - optional
// Set USE_STATION_MODE to true and fill in your network credentials
#define USE_STATION_MODE false
#define WIFI_STA_SSID    "YourNetwork"
#define WIFI_STA_PASS    "YourPassword"

// WebSocket server port
#define WS_PORT 81
#define HTTP_PORT 80

// Galvo / DAC Configuration
#define DAC_RESOLUTION   4096     // 12-bit DAC: 0-4095
#define DAC_CENTER       2048     // Midpoint = 0° deflection
#define GALVO_MAX_ANGLE  20.0f    // ±20 degrees scan range
#define SPI_SPEED        10000000 // 10 MHz SPI clock

// Scan Timing
#define POINTS_PER_SECOND  20000   // 20K PPS (match galvo spec)
#define POINT_DELAY_US     50      // 1,000,000 / 20000 = 50μs per point
#define BLANKING_DELAY_US  100     // Extra settle time when laser is off (moving)
#define CORNER_DWELL       3       // Repeat corner points for brighter corners

// Projection
#define MAX_TILES          500     // Max tiles in pattern
#define MAX_VERTS_PER_TILE 8       // Hexagon = 6, Square = 4, Herringbone = 4
#define MAX_SCAN_POINTS    20000   // Max points in scan buffer
#define MAX_VOIDS          20      // Max void regions

// Safety
#define SAFETY_CHECK_MS    10      // Check interlock every 10ms
#define LASER_TIMEOUT_MS   300000  // Auto-off after 5 minutes of no data

// LED colors
#define COLOR_READY     0x00FF00  // Green - ready for connection
#define COLOR_CONNECTED 0x0044FF  // Blue - connected to app
#define COLOR_PROJECTING 0x0088FF // Bright blue - actively projecting
#define COLOR_CALIBRATING 0xFF8800 // Amber - calibrating
#define COLOR_ERROR     0xFF0000  // Red - error state
#define COLOR_OFF       0x000000  // Off

// ============================================================================
// GLOBAL STATE
// ============================================================================

// Hardware Objects
SPIClass *dacSPI = NULL;
WebServer httpServer(HTTP_PORT);
WebSocketsServer wsServer(WS_PORT);
Adafruit_NeoPixel statusLED(1, PIN_STATUS_LED, NEO_GRB + NEO_KHZ800);

// ── Projection Data ──

// A single point in the scan buffer
struct ScanPoint {
  uint16_t x;       // DAC value 0-4095
  uint16_t y;       // DAC value 0-4095
  bool     laserOn; // true = beam visible, false = blanked (moving)
};

// Tile vertex data (received from app)
struct TileData {
  float verts[MAX_VERTS_PER_TILE][2]; // [x,y] in inches
  uint8_t vertCount;
};

// Void region (area to skip)
struct VoidRegion {
  float x, y, w, h; // in inches
};

// Pattern configuration
struct PatternConfig {
  float wallWidth;      // inches
  float wallHeight;     // inches
  float tileWidth;      // inches
  float tileHeight;     // inches
  float groutSize;      // inches
  char  tileShape[16];  // "herringbone", "hexagon", "square", "rectangle"
};

// Projection state
PatternConfig   pattern;
TileData        tiles[MAX_TILES];
uint16_t        tileCount = 0;
VoidRegion      voids[MAX_VOIDS];
uint8_t         voidCount = 0;

// Scan buffer (pre-computed DAC values)
ScanPoint       scanBuffer[MAX_SCAN_POINTS];
uint32_t        scanPointCount = 0;
volatile bool   projecting = false;
volatile bool   patternLoaded = false;

// Calibration
float           projectionDistanceFt = 6.0f;  // Default 6 feet
float           coverageInches = 0.0f;        // Computed from distance
float           inchesToDac = 1.0f;            // Conversion factor
float           originX = 0.0f;                // Projection origin offset X (inches)
float           originY = 0.0f;                // Projection origin offset Y (inches)

// Segment projection
float           segmentX = 0.0f;              // Current segment origin X (inches)
float           segmentY = 0.0f;              // Current segment origin Y (inches)
float           segmentW = 36.0f;             // Segment width (inches)
float           segmentH = 36.0f;             // Segment height (inches)

// Safety
volatile bool   safetyOK = false;
volatile bool   laserEnabled = false;
unsigned long   lastDataTime = 0;

// Connection
bool            clientConnected = false;
uint8_t         connectedClient = 0;

// LED animation
unsigned long   lastLEDUpdate = 0;
uint8_t         ledPulsePhase = 0;

// ============================================================================
// SETUP
// ============================================================================

void setup() {
  Serial.begin(115200);
  Serial.println("\n\n=== LayIt Laser v1.0 ===");
  Serial.println("Initializing...\n");

  // ── Pin Setup ──
  pinMode(PIN_LASER_TTL, OUTPUT);
  digitalWrite(PIN_LASER_TTL, HIGH);  // HIGH = MOSFET ON = TTL LOW = Laser OFF (safe default)

  pinMode(PIN_DAC_LDAC, OUTPUT);
  digitalWrite(PIN_DAC_LDAC, HIGH);   // HIGH = hold (don't latch yet)

  pinMode(PIN_SAFETY, INPUT);         // External pull-up R15

  // ── Status LED ──
  statusLED.begin();
  statusLED.setBrightness(40);  // Not blinding
  setStatusColor(COLOR_ERROR);   // Red until initialized

  // ── Safety Check ──
  safetyOK = (digitalRead(PIN_SAFETY) == LOW);
  if (!safetyOK) {
    Serial.println("WARNING: Safety interlock OPEN. Close enclosure lid.");
  }

  // ── SPI for DAC ──
  dacSPI = new SPIClass(HSPI);
  dacSPI->begin(PIN_SPI_CLK, -1, PIN_SPI_MOSI, PIN_SPI_CS);
  pinMode(PIN_SPI_CS, OUTPUT);
  digitalWrite(PIN_SPI_CS, HIGH);  // Deselect DAC

  // Center the galvos at startup
  writeDACBoth(DAC_CENTER, DAC_CENTER);
  Serial.println("DAC initialized, galvos centered.");

  // ── WiFi ──
  setupWiFi();

  // ── HTTP Server (for status page) ──
  setupHTTPServer();
  httpServer.begin();
  Serial.println("HTTP server started on port 80");

  // ── WebSocket Server ──
  wsServer.begin();
  wsServer.onEvent(onWebSocketEvent);
  Serial.println("WebSocket server started on port 81");

  // ── Safety Interrupt ──
  attachInterrupt(digitalPinToInterrupt(PIN_SAFETY), safetyISR, CHANGE);

  // ── Ready ──
  setStatusColor(COLOR_READY);
  lastDataTime = millis();

  Serial.println("\n=== LayIt Laser READY ===");
  Serial.printf("Connect to WiFi: %s\n", WIFI_AP_SSID);
  Serial.printf("Password: %s\n", WIFI_AP_PASSWORD);
  Serial.printf("WebSocket: ws://%s:%d\n", WiFi.softAPIP().toString().c_str(), WS_PORT);
}

// ============================================================================
// MAIN LOOP
// ============================================================================

void loop() {
  // Handle network
  httpServer.handleClient();
  wsServer.loop();

  // Safety check (redundant with ISR, but belt-and-suspenders)
  safetyOK = (digitalRead(PIN_SAFETY) == LOW);

  // Auto-timeout: disable laser if no data for 5 minutes
  if (millis() - lastDataTime > LASER_TIMEOUT_MS && laserEnabled) {
    Serial.println("TIMEOUT: No data for 5 minutes. Laser disabled.");
    stopProjection();
  }

  // If projecting, run the scan loop
  if (projecting && patternLoaded && safetyOK) {
    runScanLoop();
  } else if (projecting && !safetyOK) {
    // Safety tripped during projection
    emergencyStop();
  }

  // Update LED animation
  updateStatusLED();
}

// ============================================================================
// WiFi SETUP
// ============================================================================

void setupWiFi() {
  if (USE_STATION_MODE) {
    // Connect to existing network
    Serial.printf("Connecting to WiFi: %s\n", WIFI_STA_SSID);
    WiFi.mode(WIFI_AP_STA);
    WiFi.begin(WIFI_STA_SSID, WIFI_STA_PASS);

    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 20) {
      delay(500);
      Serial.print(".");
      attempts++;
    }

    if (WiFi.status() == WL_CONNECTED) {
      Serial.printf("\nConnected! IP: %s\n", WiFi.localIP().toString().c_str());
    } else {
      Serial.println("\nFailed to connect. Falling back to AP mode.");
    }
  }

  // Always create AP (even in station mode, for direct connection)
  WiFi.softAP(WIFI_AP_SSID, WIFI_AP_PASSWORD, WIFI_AP_CHANNEL, 0, WIFI_AP_MAX_CONN);
  Serial.printf("AP started: %s @ %s\n", WIFI_AP_SSID, WiFi.softAPIP().toString().c_str());
}

// ============================================================================
// HTTP SERVER (Status Page)
// ============================================================================

void setupHTTPServer() {
  httpServer.on("/", HTTP_GET, []() {
    String html = "<!DOCTYPE html><html><head><title>LayIt Laser</title>";
    html += "<meta name='viewport' content='width=device-width,initial-scale=1'>";
    html += "<style>body{font-family:system-ui;background:#0d1117;color:#e6edf3;padding:20px;max-width:600px;margin:0 auto;}";
    html += "h1{color:#4ade80;}.s{color:#8b949e;}.v{color:#f0a000;font-size:1.2em;}</style></head>";
    html += "<body><h1>&#x2B22; LayIt Laser</h1>";
    html += "<p class='s'>Status Page</p><hr>";
    html += "<p>Safety Interlock: <span class='v'>" + String(safetyOK ? "OK (Closed)" : "OPEN - Laser Disabled") + "</span></p>";
    html += "<p>Client Connected: <span class='v'>" + String(clientConnected ? "Yes" : "No") + "</span></p>";
    html += "<p>Pattern Loaded: <span class='v'>" + String(patternLoaded ? "Yes" : "No") + "</span></p>";
    html += "<p>Projecting: <span class='v'>" + String(projecting ? "Yes" : "No") + "</span></p>";
    html += "<p>Tiles: <span class='v'>" + String(tileCount) + "</span></p>";
    html += "<p>Scan Points: <span class='v'>" + String(scanPointCount) + "</span></p>";
    html += "<p>Distance: <span class='v'>" + String(projectionDistanceFt, 1) + " ft</span></p>";
    html += "<p>Coverage: <span class='v'>" + String(coverageInches, 0) + " inches</span></p>";
    html += "<hr><p class='s'>WebSocket: ws://" + WiFi.softAPIP().toString() + ":81</p>";
    html += "</body></html>";
    httpServer.send(200, "text/html", html);
  });

  httpServer.on("/status", HTTP_GET, []() {
    String json = "{";
    json += "\"safety\":" + String(safetyOK ? "true" : "false") + ",";
    json += "\"connected\":" + String(clientConnected ? "true" : "false") + ",";
    json += "\"projecting\":" + String(projecting ? "true" : "false") + ",";
    json += "\"tiles\":" + String(tileCount) + ",";
    json += "\"distance\":" + String(projectionDistanceFt, 2);
    json += "}";
    httpServer.send(200, "application/json", json);
  });
}

// ============================================================================
// WEBSOCKET HANDLER
// ============================================================================

void onWebSocketEvent(uint8_t clientNum, WStype_t type, uint8_t *payload, size_t length) {
  switch (type) {

    case WStype_CONNECTED: {
      IPAddress ip = wsServer.remoteIP(clientNum);
      Serial.printf("[WS] Client #%u connected from %s\n", clientNum, ip.toString().c_str());
      clientConnected = true;
      connectedClient = clientNum;
      setStatusColor(COLOR_CONNECTED);
      lastDataTime = millis();

      // Send device info to app
      String info = "{\"type\":\"device_info\",\"name\":\"LayIt Laser\",\"version\":\"1.0\",\"safety\":"
                    + String(safetyOK ? "true" : "false") + "}";
      wsServer.sendTXT(clientNum, info);
      break;
    }

    case WStype_DISCONNECTED: {
      Serial.printf("[WS] Client #%u disconnected\n", clientNum);
      clientConnected = false;
      stopProjection();
      setStatusColor(COLOR_READY);
      break;
    }

    case WStype_TEXT: {
      lastDataTime = millis();
      handleMessage(clientNum, (char*)payload, length);
      break;
    }

    case WStype_BIN: {
      // Binary data not used currently
      Serial.printf("[WS] Received %u bytes binary (ignored)\n", length);
      break;
    }

    case WStype_PING:
    case WStype_PONG:
      break;
  }
}

// ============================================================================
// MESSAGE HANDLER — Parses commands from the LayIt app
// ============================================================================

void handleMessage(uint8_t clientNum, char *payload, size_t length) {
  // Parse JSON
  // Using ArduinoJson v7 — allocate on PSRAM if available
  JsonDocument doc;
  DeserializationError error = deserializeJson(doc, payload, length);

  if (error) {
    Serial.printf("[MSG] JSON parse error: %s\n", error.c_str());
    wsServer.sendTXT(clientNum, "{\"type\":\"error\",\"msg\":\"Invalid JSON\"}");
    return;
  }

  const char *type = doc["type"];
  if (!type) {
    wsServer.sendTXT(clientNum, "{\"type\":\"error\",\"msg\":\"Missing type field\"}");
    return;
  }

  // ── LOAD PATTERN ──
  // Receives the full .layit format from the app
  if (strcmp(type, "load_pattern") == 0) {
    Serial.println("[MSG] Loading pattern...");

    stopProjection(); // Stop current projection if any

    // Parse wall dimensions
    pattern.wallWidth  = doc["wall"]["width"] | 48.0f;
    pattern.wallHeight = doc["wall"]["height"] | 48.0f;

    // Parse tile info
    pattern.tileWidth  = doc["tile"]["width"] | 12.0f;
    pattern.tileHeight = doc["tile"]["height"] | 12.0f;
    pattern.groutSize  = doc["tile"]["grout"] | 0.125f;
    strlcpy(pattern.tileShape, doc["tile"]["shape"] | "square", sizeof(pattern.tileShape));

    // Parse voids
    voidCount = 0;
    JsonArray voidsArr = doc["voids"].as<JsonArray>();
    if (voidsArr) {
      for (JsonObject v : voidsArr) {
        if (voidCount >= MAX_VOIDS) break;
        voids[voidCount].x = v["x"] | 0.0f;
        voids[voidCount].y = v["y"] | 0.0f;
        voids[voidCount].w = v["w"] | 0.0f;
        voids[voidCount].h = v["h"] | 0.0f;
        voidCount++;
      }
    }

    // Parse tiles (array of objects with verts arrays)
    tileCount = 0;
    JsonArray tilesArr = doc["tiles"].as<JsonArray>();
    if (tilesArr) {
      for (JsonObject t : tilesArr) {
        if (tileCount >= MAX_TILES) break;

        JsonArray vertsArr = t["verts"].as<JsonArray>();
        tiles[tileCount].vertCount = 0;

        if (vertsArr) {
          for (JsonArray vert : vertsArr) {
            uint8_t vi = tiles[tileCount].vertCount;
            if (vi >= MAX_VERTS_PER_TILE) break;

            tiles[tileCount].verts[vi][0] = vert[0] | 0.0f;  // x in inches
            tiles[tileCount].verts[vi][1] = vert[1] | 0.0f;  // y in inches
            tiles[tileCount].vertCount++;
          }
        }
        tileCount++;
      }
    }

    Serial.printf("[MSG] Loaded: %d tiles, %d voids, wall %.0fx%.0f\"\n",
                  tileCount, voidCount, pattern.wallWidth, pattern.wallHeight);

    // Compute projection mapping
    computeProjectionMapping();

    // Build scan buffer
    buildScanBuffer();

    patternLoaded = true;

    // Acknowledge to app
    String ack = "{\"type\":\"pattern_loaded\",\"tiles\":" + String(tileCount)
                 + ",\"points\":" + String(scanPointCount) + "}";
    wsServer.sendTXT(clientNum, ack);

    setStatusColor(COLOR_CONNECTED);
  }

  // ── SET SEGMENT ──
  // App tells us which 36"x36" segment to project
  else if (strcmp(type, "set_segment") == 0) {
    segmentX = doc["x"] | 0.0f;
    segmentY = doc["y"] | 0.0f;
    segmentW = doc["width"] | 36.0f;
    segmentH = doc["height"] | 36.0f;

    Serial.printf("[MSG] Segment: origin(%.1f, %.1f) size(%.1fx%.1f)\n",
                  segmentX, segmentY, segmentW, segmentH);

    // Rebuild scan buffer for this segment
    if (patternLoaded) {
      buildScanBuffer();
      wsServer.sendTXT(clientNum, "{\"type\":\"segment_set\",\"points\":" + String(scanPointCount) + "}");
    }
  }

  // ── SET DISTANCE ──
  // App sets projection distance (from camera or manual input)
  else if (strcmp(type, "set_distance") == 0) {
    projectionDistanceFt = doc["distance"] | 6.0f;
    Serial.printf("[MSG] Distance set: %.1f ft\n", projectionDistanceFt);

    computeProjectionMapping();
    if (patternLoaded) {
      buildScanBuffer();
    }

    wsServer.sendTXT(clientNum, "{\"type\":\"distance_set\",\"coverage\":" + String(coverageInches, 1) + "}");
  }

  // ── START PROJECTION ──
  else if (strcmp(type, "start") == 0) {
    if (!patternLoaded) {
      wsServer.sendTXT(clientNum, "{\"type\":\"error\",\"msg\":\"No pattern loaded\"}");
      return;
    }
    if (!safetyOK) {
      wsServer.sendTXT(clientNum, "{\"type\":\"error\",\"msg\":\"Safety interlock open\"}");
      return;
    }

    Serial.println("[MSG] Starting projection");
    projecting = true;
    laserEnabled = true;
    setStatusColor(COLOR_PROJECTING);
    wsServer.sendTXT(clientNum, "{\"type\":\"projecting\",\"active\":true}");
  }

  // ── STOP PROJECTION ──
  else if (strcmp(type, "stop") == 0) {
    Serial.println("[MSG] Stopping projection");
    stopProjection();
    wsServer.sendTXT(clientNum, "{\"type\":\"projecting\",\"active\":false}");
    if (clientConnected) setStatusColor(COLOR_CONNECTED);
  }

  // ── CALIBRATE ──
  // Project a known-size square for the user to measure
  else if (strcmp(type, "calibrate") == 0) {
    float calSize = doc["size"] | 12.0f; // Default 12" calibration square
    Serial.printf("[MSG] Calibration: %.0f\" square\n", calSize);
    setStatusColor(COLOR_CALIBRATING);
    buildCalibrationPattern(calSize);
    projecting = true;
    laserEnabled = true;
  }

  // ── PING ──
  else if (strcmp(type, "ping") == 0) {
    wsServer.sendTXT(clientNum, "{\"type\":\"pong\"}");
  }

  else {
    Serial.printf("[MSG] Unknown type: %s\n", type);
  }
}

// ============================================================================
// PROJECTION MAPPING — Converts inches to DAC values
// ============================================================================

void computeProjectionMapping() {
  // At distance d (feet), coverage = d * 12 * 0.73 (inches)
  // Based on ±20° galvo scan angle: 2 * tan(20°) ≈ 0.73
  coverageInches = projectionDistanceFt * 12.0f * 0.728f;

  // DAC values per inch of projection
  // Full DAC range (0-4095) maps to full coverage
  inchesToDac = (float)DAC_RESOLUTION / coverageInches;

  Serial.printf("[MAP] Distance: %.1f ft, Coverage: %.1f\", Scale: %.1f DAC/inch\n",
                projectionDistanceFt, coverageInches, inchesToDac);
}

// Convert wall coordinates (inches) to DAC values
// Returns false if the point is outside the projection area
bool inchesToDAC(float xInch, float yInch, uint16_t &dacX, uint16_t &dacY) {
  // Translate relative to current segment origin
  float relX = xInch - segmentX - originX;
  float relY = yInch - segmentY - originY;

  // Convert to DAC values (centered at DAC_CENTER)
  float dx = relX * inchesToDac;
  float dy = relY * inchesToDac;

  // Map to DAC range: center ± half range
  int32_t rawX = DAC_CENTER + (int32_t)dx;
  int32_t rawY = DAC_CENTER + (int32_t)dy;

  // Clamp to valid range
  if (rawX < 0 || rawX >= DAC_RESOLUTION || rawY < 0 || rawY >= DAC_RESOLUTION) {
    return false; // Outside projection area
  }

  dacX = (uint16_t)rawX;
  dacY = (uint16_t)rawY;
  return true;
}

// ============================================================================
// SCAN BUFFER BUILDER — Converts tile data into optimized scan path
// ============================================================================

void buildScanBuffer() {
  scanPointCount = 0;

  if (tileCount == 0) return;

  Serial.printf("[SCAN] Building scan buffer for %d tiles, segment(%.0f,%.0f)...\n",
                tileCount, segmentX, segmentY);

  // For each tile, check if any vertex falls within the current segment
  for (uint16_t t = 0; t < tileCount; t++) {
    if (tiles[t].vertCount < 3) continue;

    // Check if this tile overlaps the current segment
    if (!tileInSegment(t)) continue;

    // Add tile outline to scan buffer
    addTileToScanBuffer(t);
  }

  Serial.printf("[SCAN] Buffer built: %u points\n", scanPointCount);
}

bool tileInSegment(uint16_t tileIdx) {
  // Check if any vertex of this tile is within the segment bounds
  // (with a small margin for partial tiles)
  float margin = 1.0f; // 1 inch margin

  for (uint8_t v = 0; v < tiles[tileIdx].vertCount; v++) {
    float x = tiles[tileIdx].verts[v][0];
    float y = tiles[tileIdx].verts[v][1];

    if (x >= segmentX - margin && x <= segmentX + segmentW + margin &&
        y >= segmentY - margin && y <= segmentY + segmentH + margin) {
      return true;
    }
  }
  return false;
}

void addTileToScanBuffer(uint16_t tileIdx) {
  TileData &tile = tiles[tileIdx];

  // Move to first vertex (blanked)
  uint16_t dacX, dacY;
  if (!inchesToDAC(tile.verts[0][0], tile.verts[0][1], dacX, dacY)) return;

  // Blanking move to start position
  addScanPoint(dacX, dacY, false);
  addScanPoint(dacX, dacY, false); // Extra settle time

  // Draw tile outline
  for (uint8_t v = 0; v < tile.vertCount; v++) {
    if (!inchesToDAC(tile.verts[v][0], tile.verts[v][1], dacX, dacY)) continue;

    // Corner dwell: repeat point for brighter corners
    for (uint8_t d = 0; d < CORNER_DWELL; d++) {
      addScanPoint(dacX, dacY, true);
    }

    // Interpolate line to next vertex for smoother lines
    uint8_t nextV = (v + 1) % tile.vertCount;
    uint16_t nextDacX, nextDacY;
    if (inchesToDAC(tile.verts[nextV][0], tile.verts[nextV][1], nextDacX, nextDacY)) {
      interpolateLine(dacX, dacY, nextDacX, nextDacY, true);
    }
  }

  // Close the shape: return to first vertex
  if (inchesToDAC(tile.verts[0][0], tile.verts[0][1], dacX, dacY)) {
    for (uint8_t d = 0; d < CORNER_DWELL; d++) {
      addScanPoint(dacX, dacY, true);
    }
  }

  // Blank after tile
  addScanPoint(dacX, dacY, false);
}

// Interpolate between two points for smoother galvo movement
void interpolateLine(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, bool laser) {
  int32_t dx = (int32_t)x2 - (int32_t)x1;
  int32_t dy = (int32_t)y2 - (int32_t)y1;

  // Calculate distance in DAC units
  float dist = sqrtf((float)(dx * dx + dy * dy));

  // Add intermediate points every ~50 DAC units (about 1° galvo movement)
  // This ensures smooth lines even for long segments
  int steps = (int)(dist / 50.0f);
  if (steps < 1) steps = 1;
  if (steps > 100) steps = 100; // Cap to prevent buffer overflow

  for (int s = 1; s <= steps; s++) {
    float t = (float)s / (float)(steps + 1);
    uint16_t ix = x1 + (uint16_t)(t * dx);
    uint16_t iy = y1 + (uint16_t)(t * dy);
    addScanPoint(ix, iy, laser);
  }
}

void addScanPoint(uint16_t x, uint16_t y, bool laserOn) {
  if (scanPointCount >= MAX_SCAN_POINTS) return;

  scanBuffer[scanPointCount].x = x;
  scanBuffer[scanPointCount].y = y;
  scanBuffer[scanPointCount].laserOn = laserOn;
  scanPointCount++;
}

// Build a calibration square pattern (for verifying projection size)
void buildCalibrationPattern(float sizeInches) {
  scanPointCount = 0;

  float halfSize = sizeInches / 2.0f;

  // Center of projection
  float cx = segmentX + segmentW / 2.0f;
  float cy = segmentY + segmentH / 2.0f;

  // Four corners of calibration square
  float corners[4][2] = {
    {cx - halfSize, cy - halfSize},  // Bottom-left
    {cx + halfSize, cy - halfSize},  // Bottom-right
    {cx + halfSize, cy + halfSize},  // Top-right
    {cx - halfSize, cy + halfSize}   // Top-left
  };

  // Draw square
  uint16_t dacX, dacY;

  for (int c = 0; c < 4; c++) {
    if (!inchesToDAC(corners[c][0], corners[c][1], dacX, dacY)) continue;

    // Move to corner (blanked if first)
    bool laser = (c > 0);
    for (int d = 0; d < CORNER_DWELL * 2; d++) {
      addScanPoint(dacX, dacY, laser);
    }

    // Line to next corner
    int nextC = (c + 1) % 4;
    uint16_t nextX, nextY;
    if (inchesToDAC(corners[nextC][0], corners[nextC][1], nextX, nextY)) {
      interpolateLine(dacX, dacY, nextX, nextY, true);
    }
  }

  // Close the square
  if (inchesToDAC(corners[0][0], corners[0][1], dacX, dacY)) {
    for (int d = 0; d < CORNER_DWELL * 2; d++) {
      addScanPoint(dacX, dacY, true);
    }
  }

  // Add crosshair at center
  uint16_t cxDac, cyDac;
  if (inchesToDAC(cx, cy, cxDac, cyDac)) {
    // Horizontal line through center
    uint16_t lx, rx, ty, by2;
    if (inchesToDAC(cx - halfSize * 0.3f, cy, lx, ty) &&
        inchesToDAC(cx + halfSize * 0.3f, cy, rx, by2)) {
      addScanPoint(lx, ty, false);
      addScanPoint(lx, ty, false);
      interpolateLine(lx, ty, rx, ty, true);
      addScanPoint(rx, ty, true);
    }
    // Vertical line through center
    uint16_t bx, tx;
    if (inchesToDAC(cx, cy - halfSize * 0.3f, bx, by2) &&
        inchesToDAC(cx, cy + halfSize * 0.3f, tx, ty)) {
      addScanPoint(bx, by2, false);
      addScanPoint(bx, by2, false);
      interpolateLine(bx, by2, bx, ty, true);
      addScanPoint(bx, ty, true);
    }
  }

  Serial.printf("[CAL] Calibration pattern: %.0f\" square, %u points\n", sizeInches, scanPointCount);
}

// ============================================================================
// SCAN LOOP — Outputs points to DAC at 20K PPS
// ============================================================================

void runScanLoop() {
  if (scanPointCount == 0) return;

  // Run through the entire scan buffer once per call
  // This should be called from loop() — it blocks for the duration of one frame

  for (uint32_t i = 0; i < scanPointCount; i++) {
    // Safety check mid-scan
    if (!safetyOK || !projecting) {
      laserOff();
      return;
    }

    ScanPoint &pt = scanBuffer[i];

    // Set laser state
    if (pt.laserOn && laserEnabled) {
      laserOn();
    } else {
      laserOff();
    }

    // Write X and Y to DAC simultaneously
    writeDACBoth(pt.x, pt.y);

    // Timing: maintain consistent point rate
    if (pt.laserOn) {
      delayMicroseconds(POINT_DELAY_US);
    } else {
      delayMicroseconds(BLANKING_DELAY_US); // Longer delay for blanking moves
    }
  }

  // After full frame, brief blank before restart
  laserOff();
  delayMicroseconds(BLANKING_DELAY_US * 2);
}

// ============================================================================
// DAC CONTROL — MCP4822 via SPI
// ============================================================================

// Write to a single DAC channel
// channel: 0 = A (Galvo X), 1 = B (Galvo Y)
// value: 0-4095 (12-bit)
void writeDAC(uint8_t channel, uint16_t value) {
  if (value > 4095) value = 4095;

  // MCP4822 16-bit command:
  // Bit 15:    Channel (0=A, 1=B)
  // Bit 14:    Buffer (1=buffered)
  // Bit 13:    Gain (0=2x → 0-4.096V, 1=1x → 0-2.048V)
  // Bit 12:    Shutdown (1=active)
  // Bits 11-0: Data

  uint16_t command = 0;
  command |= (channel & 0x01) << 15;  // Channel select
  command |= 0x01 << 14;               // Buffered
  command |= 0x00 << 13;               // 2x gain (full 0-4.096V range)
  command |= 0x01 << 12;               // Active (not shutdown)
  command |= (value & 0x0FFF);         // 12-bit data

  dacSPI->beginTransaction(SPISettings(SPI_SPEED, MSBFIRST, SPI_MODE0));
  digitalWrite(PIN_SPI_CS, LOW);
  dacSPI->transfer16(command);
  digitalWrite(PIN_SPI_CS, HIGH);
  dacSPI->endTransaction();
}

// Write both channels and latch simultaneously
void writeDACBoth(uint16_t valueA, uint16_t valueB) {
  // Hold LDAC high (don't latch yet)
  digitalWrite(PIN_DAC_LDAC, HIGH);

  // Write Channel A (Galvo X)
  writeDAC(0, valueA);

  // Write Channel B (Galvo Y)
  writeDAC(1, valueB);

  // Pulse LDAC low to latch both channels simultaneously
  // This ensures X and Y update at the exact same moment
  digitalWrite(PIN_DAC_LDAC, LOW);
  delayMicroseconds(1); // Minimum pulse width: 100ns
  digitalWrite(PIN_DAC_LDAC, HIGH);
}

// ============================================================================
// LASER CONTROL
// ============================================================================

// NOTE: The MOSFET inverts the signal.
// ESP32 HIGH → MOSFET ON → TTL LOW → Laser OFF
// ESP32 LOW  → MOSFET OFF → TTL HIGH → Laser ON

void laserOn() {
  if (!safetyOK || !laserEnabled) return;
  digitalWrite(PIN_LASER_TTL, LOW);   // Inverted: LOW turns laser ON
}

void laserOff() {
  digitalWrite(PIN_LASER_TTL, HIGH);  // Inverted: HIGH turns laser OFF
}

void stopProjection() {
  projecting = false;
  laserEnabled = false;
  laserOff();
  // Center galvos
  writeDACBoth(DAC_CENTER, DAC_CENTER);
  Serial.println("[PROJ] Projection stopped.");
}

void emergencyStop() {
  laserOff();
  projecting = false;
  laserEnabled = false;
  writeDACBoth(DAC_CENTER, DAC_CENTER);
  setStatusColor(COLOR_ERROR);
  Serial.println("[SAFETY] EMERGENCY STOP - Interlock opened!");

  if (clientConnected) {
    wsServer.sendTXT(connectedClient, "{\"type\":\"safety_stop\",\"msg\":\"Enclosure opened\"}");
  }
}

// ============================================================================
// SAFETY INTERLOCK ISR
// ============================================================================

void IRAM_ATTR safetyISR() {
  // Read safety pin
  safetyOK = (digitalRead(PIN_SAFETY) == LOW);

  // If unsafe, immediately disable laser (in ISR context for minimum latency)
  if (!safetyOK) {
    digitalWrite(PIN_LASER_TTL, HIGH); // Laser OFF immediately
    laserEnabled = false;
  }
}

// ============================================================================
// STATUS LED
// ============================================================================

void setStatusColor(uint32_t color) {
  statusLED.setPixelColor(0, color);
  statusLED.show();
}

void updateStatusLED() {
  if (millis() - lastLEDUpdate < 50) return; // 20Hz LED update rate
  lastLEDUpdate = millis();

  ledPulsePhase += 4;

  // Pulsing effect for certain states
  if (!safetyOK) {
    // Fast red blink for safety error
    uint8_t brightness = (millis() / 200) % 2 ? 255 : 0;
    statusLED.setPixelColor(0, statusLED.Color(brightness, 0, 0));
  }
  else if (projecting) {
    // Solid bright blue while projecting
    statusLED.setPixelColor(0, COLOR_PROJECTING);
  }
  else if (clientConnected) {
    // Slow blue pulse when connected but idle
    uint8_t brightness = (sin(ledPulsePhase * 0.05f) + 1.0f) * 64;
    statusLED.setPixelColor(0, statusLED.Color(0, brightness / 4, brightness));
  }
  else {
    // Slow green pulse when ready
    uint8_t brightness = (sin(ledPulsePhase * 0.03f) + 1.0f) * 64;
    statusLED.setPixelColor(0, statusLED.Color(0, brightness, 0));
  }

  statusLED.show();
}

// ============================================================================
// CAMERA (Placeholder — for auto-distance and calibration)
// ============================================================================

/*
 * Camera integration is a Phase 2 feature. The OV5640 camera is used for:
 *
 * 1. Auto-distance detection:
 *    - Project a known-size reference pattern
 *    - Capture with camera
 *    - Measure apparent size in pixels
 *    - Calculate distance from known size vs. apparent size
 *
 * 2. Auto-calibration:
 *    - Detect reflective markers placed on the wall
 *    - Compute perspective transform
 *    - Correct projection for non-perpendicular angles
 *
 * 3. Surface detection:
 *    - Detect wall boundaries
 *    - Identify obstacles
 *
 * To implement, use the esp_camera library with these pin definitions
 * (already defined at top of file). Example initialization:
 *
 * camera_config_t config;
 * config.ledc_channel = LEDC_CHANNEL_0;
 * config.ledc_timer = LEDC_TIMER_0;
 * config.pin_d0 = PIN_CAM_D2;  // Note: DVP D2 maps to driver D0
 * config.pin_d1 = PIN_CAM_D3;
 * config.pin_d2 = PIN_CAM_D4;
 * config.pin_d3 = PIN_CAM_D5;
 * config.pin_d4 = PIN_CAM_D6;
 * config.pin_d5 = PIN_CAM_D7;
 * config.pin_d6 = PIN_CAM_D8;
 * config.pin_d7 = PIN_CAM_D9;
 * config.pin_xclk = PIN_CAM_XCLK;
 * config.pin_pclk = PIN_CAM_PCLK;
 * config.pin_vsync = PIN_CAM_VSYNC;
 * config.pin_href = PIN_CAM_HREF;
 * config.pin_sccb_sda = PIN_CAM_SDA;
 * config.pin_sccb_scl = PIN_CAM_SCL;
 * config.xclk_freq_hz = 20000000;
 * config.pixel_format = PIXFORMAT_JPEG;
 * config.frame_size = FRAMESIZE_VGA;
 * config.fb_count = 2;
 * config.fb_location = CAMERA_FB_IN_PSRAM;
 *
 * esp_err_t err = esp_camera_init(&config);
 */

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

// Check if a point is inside any void region
bool isInVoid(float x, float y) {
  for (uint8_t v = 0; v < voidCount; v++) {
    if (x >= voids[v].x && x <= voids[v].x + voids[v].w &&
        y >= voids[v].y && y <= voids[v].y + voids[v].h) {
      return true;
    }
  }
  return false;
}

// Calculate distance between two scan points (for path optimization)
float pointDistance(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2) {
  int32_t dx = (int32_t)x2 - (int32_t)x1;
  int32_t dy = (int32_t)y2 - (int32_t)y1;
  return sqrtf((float)(dx * dx + dy * dy));
}
